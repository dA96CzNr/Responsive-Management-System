<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--    [Site Title] -->
    <title>Account</title>


    <!--    [Bootstrap Css] -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--    [Animate Css]-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--    [FontAwesome Css] -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--    [IcoFont Css] -->
    <link rel="stylesheet" href="assets/css/icofont.css">

    <!--    [OwlCarousel Css]-->
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">

    <!--    [Custom Stlesheet]-->
    <link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="assets/css/responsive.css">


    <!--    [Favicon] -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">


</head>
<body>
   
   <header>
        <div class="wrapper">
            <!-- Sidebar Holder -->
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>DASHBOARD</h3>
                    <strong>DS</strong>
                </div>

                <ul class="list-unstyled components">
                    <li class="active">
                        <a href="index.php" >
                            
                            Home
                        </a>
                    </li>
                    <li>
                        <a href="Incoming_Funds.php">
                           
                            Incoming Funds
                        </a>
                    </li>
                    <li>
                        <a href="Expenses_Funds.php">
                           
                           Expenses Funds
                        </a>
                    </li>
                    <li>
                        <a href="account.php">
                          
                            Account
                        </a>
                    </li>
                    <li>
                        <a href="Account_rec.php">
                           
                            Recievables
                        </a>
                    </li>
                    <li>
                        <a href="client.php">
                          
                            Clients
                        </a>
                    </li>
                    <li>
                        <a href="project.php">
                     
                            Project
                        </a>
                    </li>
                </ul>
            </nav>

            <!-- Page Content Holder -->
            <div id="content">

            <nav class="navbar navbar-default ">
                  <div class="container-fluid">

                        <div class="navbar-header">
                             <button type="button" id="sidebarCollapse" class="btn navbar-btn tog">
                                 <i class="fa fa-caret-square-o-left " aria-hidden="true"></i>
                                  <span>Toggle Sidebar</span>
                             </button>
                         </div>
                        <form class='navbar-form mr-auto ml-auto' >
                          <div class='input-group'>
                            <input class='form-control field mr-sm-3' type='text' name='search' placeholder='search..' />
                            <span class="input-group-btn">
                             <button class="btn but btn-secondary my-0 my-sm-0 "  type='submit'>
                                 <i class="fa fa-search" aria-hidden="true"></i>
                              </button>
                            </span>
                         </div>
                       </form> 

                       <div class="dropdown navbar-right">
                        <a href="#" class=" user" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true">
                           <i class="fa fa-user-o" aria-hidden="true"></i>
                        </a>
                        <div class="dropdown-menu logout" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item " href="#"><h5 id="user">Username</h5></a>
                            <a class="dropdown-item " href="#">Logout</a>

                      </div>
                      </div>
                  </div>
          </nav>

                
                
 <section>       
        <ul class="nav nav-tabs justify-content-center " role="tablist">
              <li class="nav-item tab">
                <a class="nav-link active" data-toggle="tab" href="#show" role="tab">Show</a>
              </li>
             <li class="nav-item tab">
                <a class="nav-link " data-toggle="tab" href="#create" role="tab">Create</a>
              </li>
        </ul>

        <!-- Tab panes -->

        <div class="tab-content">
              <div class="tab-pane " id="create" role="tabpanel">
                <!-- form create within tab create -->

               <div class="container">
                  <div class="size justify-content-center">
                           <form action="">
                                <div class="form-group">
                                  <label>Type:</label>
                                      <div class="radio">
                                        <label><input type="radio" name="type">Cash</label>
                                      </div>
                                      <div class="radio">
                                        <label><input type="radio" name="type">Bank</label>
                                      </div>
                                       <label>Account Name:</label>
                                      <input type="text"class="form-control col-lg-8">
                                </div>


                            <button type="submit" class="btn btn-default btn-secondary">Submit</button>
                          </form>
                 </div>
             </div>


             </div>

              <div class="tab-pane active" id="show" role="tabpanel">
                  <!-- tab for table show -->
                        <center>
                          <div class="container">
                          <div class="col-lg-4">
                          <table class="table table-bordered table-hover text-center border">
                      <thead class="thead-inverse">
                        <tr>
                          <th class="text-center">Cash</th>
                          <th class="text-center">Bank</th>
                          <th class="text-center">Account Name</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Mark</td>
                          <td>Otto</td>
                          <td>Otto</td>
                        </tr>
                        <tr>
                          <td>Jacob</td>
                          <td>Thornton</td>
                          <td>Otto</td>
                        </tr>
                        <tr>
                          <td>Larry</td>
                          <td>the Bird</td>
                          <td>Otto</td>
                        </tr>
                      </tbody>
                    </table>
                          </div>
                          </div> 
                          </center>  
             </div>
        </div>
 </section>          

                
                
            </div>
        </div>
       </header>
        <!-- Nav tabs -->
        
 
     
    
   
    
   
     
   
   
  
    
    
    
    
    
 
    
     <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

    <!--    [jQuery]-->
    <script src="assets/js/jquery-3.2.1.min.js"></script>

    <!--    [Popper Js] -->
    <script src="assets/js/popper.min.js"></script>

    <!--    [Bootstrap Js] -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!--    [OwlCarousel Js]-->
    <script src="assets/js/owl.carousel.min.js"></script>

    <!--    [Navbar Fixed Js] -->
    <script src="assets/js/navbar-fixed.js"></script>

    <!--    [Main Custom Js] -->
    <script src="assets/js/main.js"></script>
     <!-- jQuery CDN -->
         <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
         <!-- Bootstrap Js CDN -->
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

         <script type="text/javascript">
             $(document).ready(function () {
                 $('#sidebarCollapse').on('click', function () {
                     $('#sidebar').toggleClass('active');
                 });
             });
         </script>
</body>
</html>